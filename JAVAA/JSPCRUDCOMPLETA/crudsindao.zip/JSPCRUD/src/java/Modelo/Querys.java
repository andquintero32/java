
package Modelo;

import Bean.Persona;
import com.mysql.jdbc.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Querys extends Conexion {
    
    Conexion con = new Conexion();

    public void Insertar(String doc,String nom,String ape,String email,String tel){
        
    String sql="insert into persona values(?,?, ?, ?, ?, ?)";
    try{
        PreparedStatement est = (PreparedStatement)con.getConexion().prepareStatement(sql);
        est.setString(1, null);
        est.setString(2, doc);
	est.setString(3, nom);
	est.setString(4, ape);
	est.setString(5, email);
	est.setString(6, tel);
        est.execute();
        est.close();
    }catch(Exception e){
        System.out.println(e.getMessage());
        }
       
    }
    
   public void Consultar(){
        
        
		try
		{
			String sql="select * from persona";
			
			PreparedStatement prepareStatemente=(PreparedStatement)con.getConexion().prepareStatement(sql);
			ResultSet resultSet=prepareStatemente.executeQuery();
		 	
			List<Persona> ListaPersona = new ArrayList<Persona>();
			while(resultSet.next())
			{
				Persona pe =new Persona();
				
				pe.setId(resultSet.getString("id"));
                                pe.setDocumento(resultSet.getString("documento"));
				pe.setNombre(resultSet.getString("nombre"));
				pe.setApellido(resultSet.getString("apellido"));				
				pe.setEmail(resultSet.getString("email"));
				pe.setTelefono(resultSet.getString("telefono"));
                                
				
                                
				ListaPersona.add(pe);
                               
				
			}
			
			prepareStatemente.close();
			resultSet.close();
			
			
			
		}
		catch(Exception ex)
		{
			System.out.println(ex.getMessage());
		}
		finally
		{
			con.cerrarConexion();
		}
    
    
    }
   
   public void Eliminar(String id){
   
     try
		{			
			String sql="delete from persona where id=?";
			
			PreparedStatement prepareStatemente=(PreparedStatement)con.getConexion().prepareStatement(sql);
			
			prepareStatemente.setString(1, id);
                        
			
			prepareStatemente.execute();
			
			prepareStatemente.close();
			
			
		}
		catch(Exception ex)
		{
			System.out.println(ex.getMessage());
		}
		finally
		{
			con.cerrarConexion();
		}
        
   
   }
    
  
}

