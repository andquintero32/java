
package Controlador;

import com.mysql.jdbc.PreparedStatement;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Bean.Persona;
import Modelo.Conexion;
import java.text.SimpleDateFormat;
import java.util.Date;


@WebServlet(name = "ServletActualizar", urlPatterns = {"/ServletActualizar"})
public class ServletActualizar extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
    
    }

   
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       // processRequest(request, response);
        
         Conexion con = new Conexion();
         
		try
		{
			String sql="select * from persona where id=?";
			
			PreparedStatement prepareStatemente=(PreparedStatement)con.getConexion().prepareStatement(sql);
			
			prepareStatemente.setString(1, request.getParameter("id"));
			
			ResultSet resultSet=prepareStatemente.executeQuery();
			
			Persona persona=null;
			
			while(resultSet.next())
			{
				persona=new Persona();
				
				persona.setId(resultSet.getString("id"));
				persona.setNombre(resultSet.getString("nombre"));
				persona.setApellido(resultSet.getString("apellido"));
                                persona.setEmail(resultSet.getString("email"));
                                persona.setTelefono(resultSet.getString("telefono"));
				
			}
			
			prepareStatemente.close();
			resultSet.close();
			
			request.setAttribute("persona", persona);
			
			request.getRequestDispatcher("actualizar.jsp").forward(request, response);
			
		}
		catch(Exception ex)
		{
			System.out.println(ex.getMessage());
		}
		finally
		{
			con.cerrarConexion();
		}
        
        
        
    }

   
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //processRequest(request, response);
        
        Conexion con = new Conexion();
        
		try
		{
			
			
			String sql="update persona set nombre=?, apellido=?, email=?, telefono=? where id=?";
			
			PreparedStatement prepareStatemente=(PreparedStatement)con.getConexion().prepareStatement(sql);
			
			prepareStatemente.setString(1, request.getParameter("txtNombre"));
			prepareStatemente.setString(2, request.getParameter("txtApellido"));
			prepareStatemente.setString(3, request.getParameter("txtEmail"));
			prepareStatemente.setString(4, request.getParameter("txtTelefono"));
			
                        
			prepareStatemente.setString(5, request.getParameter("txtId"));
			
			prepareStatemente.executeUpdate();
			
			prepareStatemente.close();
			
			request.getRequestDispatcher("index.jsp").forward(request, response);
			
		}
		catch(Exception ex)
		{
			System.out.println(ex.getMessage());
		}
		finally
		{
			con.cerrarConexion();
		}
        
        
        
        
    }

    
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
