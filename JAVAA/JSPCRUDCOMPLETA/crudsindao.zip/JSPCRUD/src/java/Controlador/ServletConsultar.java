
package Controlador;

import Bean.Persona;
import Modelo.Querys;
import Modelo.Conexion;
import com.mysql.jdbc.PreparedStatement;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet(name = "ServletConsultar", urlPatterns = {"/ServletConsultar"})
public class ServletConsultar extends HttpServlet {

 
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
        
        //Querys s = new Querys();
      
        
       // request.setAttribute("listaPersona", );
        
        Conexion con = new Conexion();
        
		try
		{
			String sql="select * from persona";
			
			PreparedStatement prepareStatemente=(PreparedStatement)con.getConexion().prepareStatement(sql);
			ResultSet resultSet=prepareStatemente.executeQuery();
		 	
			List<Persona> ListaPersona = new ArrayList<Persona>();
			while(resultSet.next())
			{
				Persona pe =new Persona();
				
				pe.setId(resultSet.getString("id"));
                                pe.setDocumento(resultSet.getString("documento"));
				pe.setNombre(resultSet.getString("nombre"));
				pe.setApellido(resultSet.getString("apellido"));				
				pe.setEmail(resultSet.getString("email"));
				pe.setTelefono(resultSet.getString("telefono"));
                                
				
                                
				ListaPersona.add(pe);
                               
				
			}
			
			prepareStatemente.close();
			resultSet.close();
                        request.setAttribute("listaPersona", ListaPersona);
                        request.getRequestDispatcher("consultar.jsp").forward(request, response);
                }
                catch(Exception e){
                    System.out.println("error"+e.getMessage());
                }
                finally{
                con.cerrarConexion();
                }
                
			
       
    }

 
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }


    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }


    public String getServletInfo() {
        return "Short description";
    }

}
