
package EJB;

import DAO.DaoTProducto;
import DBConexion.Conexion;
import Encapsulamiento.TProducto;
import com.mysql.jdbc.Connection;
import java.util.List;
import javax.ejb.Stateless;


@Stateless
public class EjbTProducto {
    
    private TProducto tProducto;
    private List<TProducto> listaTProducto;
    private Connection conexion;
    private final DaoTProducto daoTProducto;
    
    public EjbTProducto()
    {
        tProducto=new TProducto();
        daoTProducto=new DaoTProducto();
    }    
    
    public boolean insert()
    {
        boolean valorRetorno;
        try
        {
            conexion=Conexion.conexion();
            tProducto.setEstado(true);
            valorRetorno=daoTProducto.insert(tProducto, conexion);
            conexion.close();
        }
        catch(Exception ex)
        {
            valorRetorno=false;
        }
        return valorRetorno;
    }
    
    public boolean listarProductos()
    {
        boolean valorRetorno;
        try
        {
            conexion=Conexion.conexion();
            listaTProducto=daoTProducto.getAll(conexion);
            conexion.close();
            valorRetorno=true;
        }
        catch(Exception ex)
        {
            valorRetorno=false;
        }
        return valorRetorno;
    }
    
    public boolean leerPorIdProducto(String idProducto)
    {
        boolean valorRetorno;
        try
        {
            conexion=Conexion.conexion();
            tProducto=daoTProducto.getByCodigoProducto(idProducto, conexion);
            conexion.close();
            valorRetorno=true;
        }
        catch(Exception ex)
        {
            valorRetorno=false;
        }
        return valorRetorno;
    }
    
    public boolean actualizarProducto()
    {
        boolean valorRetorno;
        try
        {
            conexion=Conexion.conexion();
            daoTProducto.update(tProducto, conexion);
            conexion.close();
            valorRetorno=true;
        }
        catch(Exception ex)
        {
            valorRetorno=false;
        }
        return valorRetorno;
    }
    
    public boolean borrarProducto(String idProducto)
    {
        boolean valorRetorno;
        try
        {
            conexion=Conexion.conexion();
            daoTProducto.delete(idProducto, conexion);
            conexion.close();
            valorRetorno=true;
        }
        catch(Exception ex)
        {
            valorRetorno=false;
        }
        return valorRetorno;
    }

    public TProducto gettProducto() {
        return tProducto;
    }

    public void settProducto(TProducto tProducto) {
        this.tProducto = tProducto;
    }

    public List<TProducto> getListaTProducto() {
        return listaTProducto;
    }

    public void setListaTProducto(List<TProducto> listaTProducto) {
        this.listaTProducto = listaTProducto;
    }
}
