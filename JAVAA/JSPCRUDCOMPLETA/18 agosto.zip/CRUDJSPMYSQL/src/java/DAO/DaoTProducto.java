
package DAO;

import Encapsulamiento.TProducto;
import Interface.InterfaceDaoTProducto;
import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class DaoTProducto implements InterfaceDaoTProducto{

    @Override
    public boolean insert(TProducto tProducto, Connection conexion) throws Exception {
        Statement statement;
        statement=(Statement) conexion.createStatement();
        String query="insert into TProducto(nombre, precioVenta, fechaVencimiento, estado) values('"+tProducto.getNombre()+"','"+tProducto.getPrecioVenta()+"','"+tProducto.getFechaVencimiento()+"',"+tProducto.isEstado()+");";
        statement.execute(query);
        statement.close();
        return true;
    }

    @Override
    public TProducto getByCodigoProducto(String codigoProducto, Connection conexion) throws Exception {
        TProducto tProducto=null;
        
        Statement statement;
        ResultSet resultSet;
        
        String query="select * from TProducto where idProducto='"+codigoProducto+"'";
        
        statement=(Statement) conexion.createStatement();
        resultSet=statement.executeQuery(query);
        
        
        if(resultSet.next())
        {
            tProducto=new TProducto();
            
            tProducto.setIdProducto(resultSet.getInt("idProducto"));
            tProducto.setNombre(resultSet.getString("nombre"));
            tProducto.setPrecioVenta(resultSet.getBigDecimal("precioVenta"));
            tProducto.setFechaVencimiento(resultSet.getDate("fechaVencimiento"));
            tProducto.setEstado(resultSet.getBoolean("estado"));
            tProducto.setFechaRegistro(resultSet.getDate("fechaRegistro"));
            tProducto.setFechaModificacion(resultSet.getDate("fechaModificacion"));
        }
        
        resultSet.close();
        statement.close();
        
        return tProducto;
    }

    @Override
    public List<TProducto> getAll(Connection conexion) throws Exception {
        List<TProducto> listaTProducto=new ArrayList<TProducto>();
        
        Statement statement;
        ResultSet resultSet;
        
        String query="select * from TProducto";
        
        statement=(Statement) conexion.createStatement();
        resultSet=statement.executeQuery(query);
        
        TProducto tProducto;
        while(resultSet.next())
        {
            tProducto=new TProducto();
            
            tProducto.setIdProducto(resultSet.getInt("idProducto"));
            tProducto.setNombre(resultSet.getString("nombre"));
            tProducto.setPrecioVenta(resultSet.getBigDecimal("precioVenta"));
            tProducto.setFechaVencimiento(resultSet.getDate("fechaVencimiento"));
            tProducto.setEstado(resultSet.getBoolean("estado"));
            tProducto.setFechaRegistro(resultSet.getDate("fechaRegistro"));
            tProducto.setFechaModificacion(resultSet.getDate("fechaModificacion"));
            
            listaTProducto.add(tProducto);
        }
        
        resultSet.close();
        statement.close();
        
        return listaTProducto;
    }

    @Override
    public boolean update(TProducto tProducto, Connection conexion) throws Exception {
        Statement statement;
        
        String query="update TProducto set nombre='"+tProducto.getNombre()+"', precioVenta='"+tProducto.getPrecioVenta()+"', fechaVencimiento='"+tProducto.getFechaVencimiento()+"', estado="+tProducto.isEstado()+" where idProducto='"+tProducto.getIdProducto()+"'";
        statement=(Statement) conexion.createStatement();
        statement.execute(query);
        statement.close();
        return true;
    }

    @Override
    public boolean delete(String codigoProducto, Connection conexion) throws Exception {
        Statement statement;
        
        String query="delete from TProducto where idProducto='"+codigoProducto+"'";
        statement=(Statement) conexion.createStatement();
        statement.execute(query);
        statement.close();
        return true;
    }
    
}
