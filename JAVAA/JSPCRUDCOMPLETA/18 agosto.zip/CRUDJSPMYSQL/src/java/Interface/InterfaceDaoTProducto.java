

package Interface;

import Encapsulamiento.TProducto;
import com.mysql.jdbc.Connection;
import java.util.List;


public interface InterfaceDaoTProducto {
    public boolean insert(TProducto tProducto, Connection conexion)throws Exception;
    public TProducto getByCodigoProducto(String codigpoProducto, Connection conexion)throws Exception;
    public List<TProducto> getAll(Connection conexion)throws Exception;
    public boolean update(TProducto tProducto, Connection conexion)throws Exception;
    public boolean delete(String codigoProducto, Connection conexion)throws Exception;
}
